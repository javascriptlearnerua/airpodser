# Web Development

## [templates](/templates/)

### Templates for layout are ready-made solutions developed by me for implementation on web sites. This is also where I store sites that have been completed.

## [portfolio](/portfolio/)

### Portfolio works, my pet projects.