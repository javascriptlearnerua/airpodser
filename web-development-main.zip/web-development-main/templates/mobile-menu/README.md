# Mobile Menu 

### Created responsive [mobile menu](https://youtu.be/C4TQ_8au4K0?t=1370) with burger button via tailwindCSS