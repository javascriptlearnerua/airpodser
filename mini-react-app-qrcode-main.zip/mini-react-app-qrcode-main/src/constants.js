export const SCAN_DATA = 'scan_data';
export const GENERATE_DATA = 'generate_data';