# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

YT [Link](https://www.youtube.com/watch?v=NDPiaUfsnLA&list=WL&index=11&ab_channel=%D0%9A%D0%B0%D0%BA%D0%B8%D0%B5-%D1%82%D0%BE%D1%83%D1%80%D0%BE%D0%BA%D0%B8)
